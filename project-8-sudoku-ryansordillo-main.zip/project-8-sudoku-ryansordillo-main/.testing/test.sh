#! /bin/bash

echo "------------BEGIN TEST------------"
echo "Input to Student Program: "
cat .testing/$1
echo "Output from Student Program: "
### This version supports standard input:
cat .testing/$1 | ./a.out | tee student_output$1.txt
diff student_output$1.txt ./.testing/output.$1.baseline 2>&1 > /dev/null
### This version supports file i/o:
# ./a.out .testing/$1 | tee output.$1
#diff output.$1 ./.testing/output.$1.baseline 2>&1 > /dev/null
if [ "$?" == "0" ]; then
    echo "Woohoo! Received expected output!"
    echo "-------------END TEST-------------"
    exit "0"
else
    echo "Uh-oh...there's an issue!"
    echo "Expected: ($ = line end, weird chars = non-printable characters)"
    cat -vet ./.testing/output.$1.baseline
    echo "But got: ($ = line end, weird chars = non-printable characters)"
    cat -vet ./student_output$1.txt
    echo "-------------END TEST-------------"
    echo "Having Difficulty? Troubleshoot: "
    echo "Did your program not produce output? Run it on your own."
    echo "Don't see a difference? Double check spaces and line endings."
    exit "1"
fi
